@javax.xml.bind.annotation.XmlSchema(namespace = "http://promon.com.br/CustoProfissionalStart/")
package br.com.promon.custoprofissionalstart;
