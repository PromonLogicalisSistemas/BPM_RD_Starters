@javax.xml.bind.annotation.XmlSchema(namespace = "http://promon.com.br/HorasXColetoresStart/")
package br.com.promon.horasxcoletoresstart;
