@javax.xml.bind.annotation.XmlSchema(namespace = "http://promon.com.br/EscalasStart/")
package br.com.promon.escalasstart;
