@javax.xml.bind.annotation.XmlSchema(namespace = "http://promon.com.br/HistSituacaoStart/")
package br.com.promon.histsituacaostart;
