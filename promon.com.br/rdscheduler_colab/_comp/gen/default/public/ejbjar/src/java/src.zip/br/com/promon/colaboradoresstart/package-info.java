@javax.xml.bind.annotation.XmlSchema(namespace = "http://promon.com.br/ColaboradoresStart/")
package br.com.promon.colaboradoresstart;
